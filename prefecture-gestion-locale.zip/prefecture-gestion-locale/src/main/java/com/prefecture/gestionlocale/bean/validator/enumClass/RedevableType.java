package com.prefecture.gestionlocale.bean.validator.enumClass;

public enum RedevableType {
    PHYSIQUE,
    MORALE
}
